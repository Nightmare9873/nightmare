
namespace VoreMod
{
	public enum SpriteType
	{
		None,
		Belly,
		Balls,
		Breasts,
	}
}
