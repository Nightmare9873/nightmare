
namespace VoreMod
{
	public enum StomachType
	{
		None,
		Belly,
		Ass,
		Womb,
		Balls,
		Breasts,
	}
}
