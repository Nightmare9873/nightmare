
namespace VoreMod
{
	public enum ItemTier
	{
		None = 0,
		CopperTin = 1,
		IronLead = 2,
		SilverTungsten = 3,
		GoldPlatinum = 4,
		DemoniteCrimtane = 5,
		Hellstone = 6,
		CobaltPalladium = 7,
		MythrilOrichalcum = 8,
		TitaniumAdamantite = 9,
		Hallowed = 10,
		Chlorophyte = 11,
		Luminite = 12,
	}
}
