
namespace VoreMod
{
	public enum CharmEffect
	{
		None = 0,
		Life = 1 << 0,
		Mana = 1 << 1,
		Acid = 1 << 2,
		Hunger = 1 << 3,
		Soul = 1 << 4,
	}
}
