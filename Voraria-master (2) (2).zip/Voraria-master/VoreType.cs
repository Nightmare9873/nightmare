
namespace VoreMod
{
	public enum VoreType
	{
		None = 0,
		Oral = 1 << 0,
		Anal = 1 << 1,
		Unbirth = 1 << 2,
		Cock = 1 << 3,
		Breast = 1 << 4,
		All = ~0,
	}
}
