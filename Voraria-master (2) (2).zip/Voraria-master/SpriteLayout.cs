
namespace VoreMod
{
	public enum SpriteLayout
	{
		SizeX,
		SizeY,
		AnimX,
		AnimY,
		SizeXAnimY,
		AnimXSizeY,
	}
}