
namespace VoreMod
{
	public enum ColorMode
	{
		Default,
		Skin,
		Dye,
	}
}
